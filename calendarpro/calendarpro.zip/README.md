# Bootstrap Calender Pro
## Web Component for Servoy NG Client


Website of component library:  
http://eonasdan.github.io/bootstrap-datetimepicker/




```

elements.calendar.setOptions( { weekStart: [0-6] } )


```




## License

All source code in the repository is licensed under a dual license.  To use these components and services in your commercial or corporate internal projects, please contact sales@itechpros.com for licensing costs and information.

 * For non-commercial and open public uses: Open Software License 3.0 (https://opensource.org/licenses/OSL-3.0)
 * For commercial or non-public / in-house uses: contact sales@itechpros.com for licensing costs and information

&copy; iTech Professionals, Inc. 
http://itechpros.com
