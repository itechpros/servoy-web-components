angular.module('dateinput',['servoy']).directive('dateinput', function() {  
  return {
	  restrict: 'E',
	  scope: {
		  api: '=svyApi',
		  model: '=svyModel',
		  handlers: "=svyHandlers",
		  svyServoyapi : "="
	  },
	controller: function($scope, $element, $attrs, $window, $timeout) {

		'use strict'

		var container = $('#datepicker-value'),
			lock = false,
			formats = {
				
			
				EU: {
					
					drop: 'd/m/yy',
					input: 'DD/MM/YY',
					store: 'DD/MM/YYYY'
				
				},
				
				US: {
					
					drop: 'm/d/yy',
					input: 'MM/DD/YY',
					store: 'MM/DD/YYYY'
				
				}
				
			},
			format = formats[$scope.model.inputFormat],
			show = false,
			date,
			day,
			month,
			year
			
			
		var inputs = { 
			
			8: function(val) {	
				
				return val.substr(0, 2) + '/' + val.substr(2, 2) + '/' + val.substr(4, 4)
				
			},
			
			6: function(val) {
				
				var inp = Number(val.substr(4, 2)),
					yr = $scope.model.cutoffNextYear && inp > Number(year.substr(2, 2)) + 1 ? '19' : '20'
	
				return val.substr(0, 2) + '/' + val.substr(2, 2) + '/' + yr + val.substr(4, 2)
				
			},
			
			4: function(val) {
				
				return val.substr(0, 2) + '/' + val.substr(2, 2) + '/' + year
				
			},
			
			2: function(val) {
				
				return ($scope.model.inputFormat === 'EU' ? val + '/' + month : month + '/' + val) + '/' + year
				
			},
			
			1: function(val) {
				
				var out
				
				if (isNaN(val)) {
					
					out = ($scope.model.inputFormat === 'EU' ? day + '/' + month : month + '/' + day) + '/' + year
						
					if (val === 'Y')
						
						out = moment(out, format.input).subtract(1, 'd').format(format.input)
						
				} else
					
					out = ($scope.model.inputFormat === 'EU' ? val + '/' + month : month + '/' + val) + '/' + year
					
				return out
				
			}
			
		}
			
		container.keydown(function(e) {
			
			if (e.keyCode === 40)
				
				plusMinus('subtract')
				
			else if (e.keyCode === 38)
				
				plusMinus('add')
			
		})
		
		
		container.on('focusout', function() {
			
			if (show) {
				
				show = false
				return
				
			}
			
			var val = container.val().toUpperCase().trim(),
				len = val.length,
				out = val
				
			date = new Date()
			day = date.getDate().toString()
			month = (date.getMonth() + 1).toString()
			year = date.getFullYear().toString()

			if ((!isNaN(val) || (len === 1)) && inputs[len])
			
				out = inputs[len](val)
				
			else {
				
				out = val.replace(/\.|\-/g, '/').split('/')
				
				if (out.length === 3 && out[2].length === 2)
					
					out[2] = ($scope.model.cutoffNextYear && Number(out[2]) > Number(year.substr(2, 2)) + 1 ? '19' : '20') + out[2]  

				out = out.join('/')
				
			}
			
			
			
			lock = true
			$scope.model.dataProviderID = out
			$scope.svyServoyapi.apply('dataProviderID')
			
			$window.setTimeout(function() {
	
				container.val(moment($scope.model.dataProviderID, format.store).format($scope.model.displayFormat))
				
			}, 1)
			

			
		})
		

		container.focus(function() {
			
			var val = $scope.model.dataProviderID
			
			val && container.val(moment(val, format.store).format(format.input))
			$(this).select()
			lock = true
			
		})
		
		
		function plusMinus(dir) {
			
			var val = container.val()
			
			if (val) {
				
				container.val(moment(val, format.input)[dir](1, 'd').format(format.input))
				lock = true
				$scope.model.dataProviderID = moment(container.val(), format.input).format(format.input)
				$scope.svyServoyapi.apply('dataProviderID')
				
			}
			
		}

		
		$('#datepicker-activate').click(function() {

		   $(document).ready(function() {
			   
		   		lock = true
			   
		   		container.datepicker({
		   			
		   			dateFormat: format.drop,
					beforeShow : function() {

						show = true
						
					},
					onClose: function() {
					
						var val = moment(container.val(), format.input).format($scope.model.displayFormat)
	
						show = false
						
						$window.setTimeout(function() {
							
							if (lock) {
								
								lock = false
								return
								
							}
							
							container.val(val)
							
						}, 1)
						
						$window.setTimeout(function() {
							
							container.datepicker('destroy')
							
						}, 500)
						
					}
		   		
		   		})

				container.datepicker().on('change', function() {

					var val = moment(container.val(), format.input).format($scope.model.displayFormat)

					lock = true
					$scope.model.dataProviderID = moment(container.val(), format.input).format(format.store)
					$scope.svyServoyapi.apply('dataProviderID')

					$window.setTimeout(function() {
							
							container.val(val)
							
					}, 1)
						
				})

		   		container.datepicker().focus()
				   
		   })

		})
		
		
		$scope.$watch('model.displayFormat', function(newformat, oldformat) {
			
			var val = container.val()
			
			val && container.val(moment(val, oldformat).format($scope.model.displayFormat))
			
		})

		$scope.$watch('model.inputFormat', function(newformat, oldformat) {
			
			format = formats[$scope.model.inputFormat]
			lock = true
			$scope.model.dataProviderID = moment($scope.model.dataProviderID, formats[oldformat].input).format(format.store)
			$scope.svyServoyapi.apply('dataProviderID')
			container.val(moment($scope.model.dataProviderID, format.input).format($scope.model.displayFormat))
			
		})

		
		$scope.$watch('model.dataProviderID', function() {
			
			if (lock) {
				
				lock = false
				return
				
			}
			
			$scope.model.dataProviderID && container.val(moment($scope.model.dataProviderID, format.store).format($scope.model.displayFormat))
			
		})
		
			
	
		
	},
	templateUrl: 'dateinput/DateInput/DateInput.html'
  }
})