angular.module('pgmenuPgadmin',['servoy']).directive('pgmenuPgadmin', function() {  
    return {
      restrict: 'E',
      scope: {
    	  model: '=svyModel',
		  svyServoyapi: '=svyServoyapi'
      },
      controller: function($scope, $element, $attrs) {
    	  
    	  console.log('LOADING')
		  jQuery.loadScript = function (url, callback) {
			    jQuery.ajax({
			        url: url,
			        dataType: 'script',
			        success: callback,
			        async: true
			    });
			}
		  $.loadScript('pgmenu/pgadmin/lib/require.js',ini)

    	  
    	  
      
    	  function ini(){
if($scope.svyServoyapi && $scope.svyServoyapi.isInDesigner()) return
console.log('INI')
requirejs.config({
    baseUrl: 'pgmenu/pgadmin/lib/'})

    		  require(
    		      ['pgmenu'],
    		      function(pgmenu) {
    		         // var id = 55;
    		         // messenger.showMessage(id);

    		        var obj = this,
    		          // menu navigation bar
    		          navbar = $('#navbar-menu > ul').first(),
    		          // Drop down menu for objects
    		          $obj_mnu = navbar.find('li#mnu_file > ul.dropdown-menu').first()
    		  var i1=new pgAdmin.Browser.MenuItem({"enable":true,"name":"mnu_preferences","label":"Preferences","priority":999,"module":{},"callback":"show"})
    		  ,i2=new pgAdmin.Browser.MenuItem({"enable":true,"name":"mnu_resetlayout","label":"Reset Layout","priority":999,"module":{},"callback":"show"})

    		  console.log(i1)
    		          pgAdmin.Browser.MenuCreator(
    		            $obj_mnu,
    		   {"mnu_preferences":i1,
    		    "mnu_resetlayout":i2}//,

    		  //,{"create":{"label":"Create","priority":1,"above":false,"below":true,"single":true}}
    		          );


    		      }
    		  );


    		  }
    		  //ini()

    	  
      },
      templateUrl: 'pgmenu/pgadmin/pgadmin.html'
    };
  })